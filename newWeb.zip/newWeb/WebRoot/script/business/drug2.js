//实例化操作的对象。
var kb=new KBOperate("Drug2Action");
//封装一个分页查询的方法。
function find()
{
   var obj=new Object();
   //1.2获取到查询参数,
   obj.name=$("#txtName").val();
   //1.3执行查询操作。传需要绑定界面的id和查询的参数。
   kb.findForEasyui("dgDrug2",obj);
}
//第一步： ready 简写的语法 $(function(){})  
$(function (){
   //1.1
	find();
    //修改功能
	kb.editForEasyui(function(data){
	   kb.getMe(data.id,function(temp){	  	    
		 $('#ff').form('load',temp);
		 $('#btnSave').text("修改");
		 $('#btnSave').show();	
		 $('#btnReset').show();
		 $("#w").panel({ title: "药品销售信息修改" });
         $("#w").window("open");
		 kb.isAdd=false;
	   })		
	});
	  // 删除
     kb.delForEasyui("你确定要删除此药品销售信息？",function(){ 	 
    	 find(); 
     });

     //浏览：
     //修改功能
 	kb.browserForEasyui(function(data){
 	   kb.getMe(data.id,function(temp2){	  	    
 		 $('#ff').form('load',temp2);
 		 $('#btnSave').hide();	
 		 $('#btnReset').hide();
 		  $("#w").panel({ title: "药品销售信息浏览" });
          $("#w").window("open");
 	   })		
 	});
     
     
	
	//新增
     $('#btnAdd').click(function(){
    	 //将表单数据清空
    	$('#ff').form('clear');
    	$('#btnSave').text("新增");
		$('#btnSave').show();	
		$('#btnReset').show();
		$("#w").panel({ title: "药品销售信息新增"});
        $("#w").window("open");
    	kb.isAdd=true; 	 
     })
   
    //btnAdd被点击的情况
    $("#btnAdd").click(function () {
        $('#ff').form('clear');//清空表单内容，
        //
        $('#btnSave').show();
        $('#btnReset').show();
        //按钮的显示值。
        $('#btnSave').text("新增");
        $('#btnReset').text("重置");
        $("#w").panel({ title: "药品销售信息新增" });//设置新增窗体的标题为“角色类型信息新增”
        //将视图显示出来
        $("#w").window("open");
    });
    //保存按钮点击进行的操作。
    $("#btnSave").click(function () {
        //如果表单数据为空，直接return
       if ($("#ff").form('enableValidation').form('validate') == false)
           return;
       //有数据，将表单数据实例化，
       var obj = serializeArrayToObject("ff");//将表单数据进行对象化       
       //判断是否是新增还是修改。
       if (kb.isAdd)
       {
    	  //提交ajax
    	  obj.doType=0;   
    	  // data2:code;msg;obj;
    	  doData("Drug2Action",obj,function(data2){
    		if(data2.code!="0") {
    			//重新刷新一遍数据 
    			 find();
    			 //窗口关闭
                 $("#w").window("close");
                 //消息弹出框 ：title：, msg:
                 $.messager.show({
                     title: "提示",
                     msg: "您已经成功新增【" + obj.name + "】记录！"
                 });			
    		}	 
    	 })     
       }
       else
       {   
    	   obj.doType=1;
    	   //执行修改的ajax。
           doData("Drug2Action", obj, function (data2) {
               if (data2.code!="0")
               {
                   find();
                   $("#w").window("close");
                   //消息弹出框 ：title：, msg:
                   $.messager.show({
                       title: "提示",
                       msg: "您已经成功修改【" + obj.name + "】记录！"
                   });
               }
               else
               {
                   $.messager.alert("提示", "修改失败，错误代码：" + data, "error");
               }
           });

       }
   });       
});
//点击新增操作，

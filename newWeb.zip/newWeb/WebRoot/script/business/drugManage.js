var kb=new KBOperate("DrugAction");
function find()
{
   var obj=new Object();
   obj.name=$("#txtName").val();
   kb.findForEasyui("dgDrug",obj);
}
$(function (){
	find();
	kb.editForEasyui(function(data){
	   kb.getMe(data.id,function(temp){	  	    
		 $('#ff').form('load',temp);
		 $('#btnSave').text("修改");
		 $('#btnSave').show();	
		 $('#btnReset').show();
		 $("#w").panel({ title: "药品信息修改" });
         $("#w").window("open");
		 kb.isAdd=false;
	   })		
	});
     kb.delForEasyui("你确定要删除此药品信息？",function(){ 	 
    	 find(); 
     });
 	kb.browserForEasyui(function(data){
 	   kb.getMe(data.id,function(temp2){	  	    
 		 $('#ff').form('load',temp2);
 		 $('#btnSave').hide();	
 		 $('#btnReset').hide();
 		  $("#w").panel({ title: "药品信息浏览" });
          $("#w").window("open");
 	   })		
 	});
     $('#btnAdd').click(function(){
    	 //将表单数据清空
    	$('#ff').form('clear');
    	$('#btnSave').text("新增");
		$('#btnSave').show();	
		$('#btnReset').show();
		$("#w").panel({ title: "药品信息新增"});
        $("#w").window("open");
    	kb.isAdd=true; 	 
     })
    $("#btnAdd").click(function () {
        $('#ff').form('clear');//清空表单内容，
        //
        $('#btnSave').show();
        $('#btnReset').show();
        $('#btnSave').text("新增");
        $('#btnReset').text("重置");
        $("#w").panel({ title: "药品信息新增" });//设置新增窗体的标题为“角色类型信息新增”
        $("#w").window("open");
    });
    $("#btnSave").click(function () {
       if ($("#ff").form('enableValidation').form('validate') == false)
           return;
       var obj = serializeArrayToObject("ff");
       if (kb.isAdd)
       {
    	  obj.doType=0;   
    	  doData("DrugAction",obj,function(data2){
    		if(data2.code!="0") {
    			 find();
                 $("#w").window("close");
                 $.messager.show({
                     title: "提示",
                     msg: "您已经成功新增【" + obj.name + "】记录！"
                 });			
    		}	 
    	 })     
       }
       else
       {   
    	   obj.doType=1;
           doData("DrugAction", obj, function (data2) {
               if (data2.code!="0")
               {
                   find();
                   $("#w").window("close");
                   $.messager.show({
                       title: "提示",
                       msg: "您已经成功修改【" + obj.name + "】记录！"
                   });
               }
               else
               {
                   $.messager.alert("提示", "修改失败，错误代码：" + data, "error");
               }
           });

       }
   });       
});


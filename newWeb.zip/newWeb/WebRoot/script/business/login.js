
$(function () {
        $("#entry").click(function () {
        	var obj=serializeArrayToObject("loginForm");
            obj.doType=5;
            if($("input[name='number']").val()=="" || $("input[name='passWord']").val()==""){
                   $("input[name='number']").focus();
          	}else{
            doData("LoginAction",obj,function (data) {
            	   if(data.obj.number!=""||data.obj.passWord!==""){
            		 switch(data.obj.roleId){
            		 case 1:
            			 location.href='index.jsp';
            			 break;
            		 case 2:
            			 location.href='role1.jsp';
            			 break;
            		 case 3:
            			 location.href='role2.jsp';
            			 break;
            		 case 4:
            			 location.href='role3.jsp';
            			 break;
            		 default:
            			 location.href='index.html';
            			 break;
            		 }   
            		   
            	   }else{
            		
            		location.href ='login.jsp';
            		$("input[name='number']").focus();
            	}
            });
          }
        });
	});

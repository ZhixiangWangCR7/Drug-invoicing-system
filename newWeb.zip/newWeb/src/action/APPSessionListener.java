package action;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class APPSessionListener implements HttpSessionListener {
   private int online=0;//在线人说
    @Override
    public void sessionCreated(HttpSessionEvent httpSessionEvent) {
        online++;
        System.out.println("您是第【"+online+"】在线访问者！");
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent httpSessionEvent) {
      if (online>0)
           online--;
        System.out.println("第【"+online+"】个用户离开！");
    }
    /*获取在线人数*/
    public int getOnline(){
        return  online;
    }
}

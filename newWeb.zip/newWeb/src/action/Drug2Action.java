package action;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import bll.impl.Drug2ServiceImpl;

public class Drug2Action extends SuperAction {

	public Drug2Action()
    {	
    	//查询第一步，各个层对象的实例化。
        setBll(new Drug2ServiceImpl());
    }

	
	@Override    
	public List<Object> getConditionParam(JSONObject param) {
		// TODO Auto-generated method stub
		 List<Object>  cons=new ArrayList<Object>();
	        try {
	            cons.add(param.getString("name"));
	            cons.add(param.getInt("pageNumber"));
	            cons.add(param.getInt("rowsCount"));
	            return cons;
	        } catch (JSONException e) {
	            e.printStackTrace();
	            return  null;
	        }
	}   

}

package action;

import java.io.IOException;
import java.util.ArrayList;

import dal.impl.DrugImpl;
import model.Drug;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DrugServlet
 */
public class DrugServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DrugServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("接收到请求");
		response.setContentType("text/html;Character=utf-8");
		request.setCharacterEncoding("utf-8");
		String i=request.getParameter("url");
		int a=Integer.parseInt(i);
		DrugImpl dImpl=new DrugImpl();
		ArrayList<Drug> drugs=dImpl.query(a);
		if(drugs!=null){
			System.out.println("不为空");
			request.setAttribute("druglist", drugs);
			request.getRequestDispatcher("drugInfo.jsp").forward(request, response);
			
			
		}
		
		
	}

}

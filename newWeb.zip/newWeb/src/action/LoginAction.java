package action;

import java.util.Enumeration;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;

import org.json.JSONObject;

import bll.impl.LoginServiceImpl;


public class LoginAction extends SuperAction {
	
	public LoginAction()
    {	
    	//查询第一步，各个层对象的实例化。
        setBll(new LoginServiceImpl());
    }
	@Override
	public List<Object> getConditionParam(JSONObject param) {
		// TODO Auto-generated method stub
		return null;
	}

	
	@Override
	public void getMe(JSONObject param) {
		// TODO Auto-generated method stub
	    super.getMe(param); 
	}
	
}

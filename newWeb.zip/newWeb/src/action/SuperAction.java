package action;

import bll.SuperService;
import com.alibaba.fastjson.JSON;
import model.AbsSuperModel;
import model.Page;
import model.ReturnBean;
import org.json.JSONException;
import org.json.JSONObject;
import util.JSONAndObject;
import util.Tool;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by wph-pc on 2017/11/20.
 */
public abstract class SuperAction extends HttpServlet {
    private PrintWriter out=null;
    private JSONObject params=null;
    //多态
    private SuperService bll;

    public SuperService getBll() {
        return bll;
    }

    public void setBll(SuperService bll) {
        this.bll = bll;
    }
   //子类去实现：
    public abstract List<Object> getConditionParam(JSONObject param);//获取查询参数

    /*获取客户端参数初始化*/
    private AbsSuperModel initParameter(JSONObject param)
    {
        AbsSuperModel model= JSONAndObject.JSONObjectToJavaBean(param,bll.getModel().getClass()); //获取页面对象
        if (model.getId().trim().equals(""))
            model.setId(Tool.CreateID());
        bll.setModel(model);//设置操作实体对象
        return model;
    }
    /*构架返回客户端对象信息*/
    private Object getReturnObject(String code,String msg,Object obj)
    {
        ReturnBean returnObj=new ReturnBean();
        returnObj.setCode(code);
        returnObj.setMessage(msg);
        returnObj.setObj(obj);
        return  returnObj;
    }
    /*更新参数model实体信息,可以由子类重写*/
    public AbsSuperModel updateModel(AbsSuperModel model)
    {
        return model;
    }
    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html");
        response.setCharacterEncoding("utf-8");
        out = ControlTool.GetResonseOutObject(response);
        //查询第二步：将页面传过来的数据转成JSONObject
        JSONObject param= ControlTool.GetRequestJSON(request,response);//获取页面JSON对象参数
        params=param;//赋值到成员变量
       // List<Map<String,Object>> data = new ArrayList<Map<String,Object>>();
        int doType=ControlTool.GetDoType(params);//获取操作类型
        //获取操作类型
        switch(doType)
        {
            case 0:
                add(param);
                break;
            case 1:
                edit(param);
                break;
            case 2:
                del(param);
                break;
            case 3:
                find(param);
                break;
            case 4:
                findByPage(param);//回调数据到前台页面
            	break;
            case 5:
                getMe(param);
                break;
            case 6:
                deleteAll(param);
                break;
        }      
        out.flush();
        out.close();
    }
  
    public void add(JSONObject param) {
        AbsSuperModel model=updateModel(initParameter(param));//获取客户端参数信息
        bll.setModel(model);
        out.write(JSON.toJSONString(getReturnObject(String.valueOf(bll.save()),"新增操作",model)));
    }
    public void edit(JSONObject param) {
        AbsSuperModel model=updateModel(initParameter(param));//获取客户端参数信息
        bll.setModel(model);
        out.write(JSON.toJSONString(getReturnObject(String.valueOf(bll.update()),"修改操作",model)));
    }
    public void del(JSONObject param) {
        AbsSuperModel model=updateModel(initParameter(param));//获取客户端参数信息
        bll.setModel(model);
        out.write(JSON.toJSONString(getReturnObject(String.valueOf(bll.delete()),"删除操作",model)));
    }
    public void deleteAll(JSONObject param) {
        try {
            String[] temp=param.getString("ids").split(",");
            List<String> ids=new ArrayList<String>();
            for(String str:temp)
            {
                if (!str.trim().equals(""))
                    ids.add(str.trim());
            }
            out.write(JSON.toJSONString(getReturnObject(String.valueOf(bll.batchDelete(ids)),"批量删除操作",null)));
        } catch (JSONException e) {
            e.printStackTrace();
            out.write(JSON.toJSONString(getReturnObject("0","批量删除操作失败",null)));
        }

    }
    public void find(JSONObject param) {
        List<Object> values=getConditionParam(param);//获取查询参数
        if (bll==null)
            out.write(JSON.toJSONString(getReturnObject("000000","系统没有提供业务对象",null)));
        if (values==null || values.size()==0)
            out.write(JSON.toJSONString(getReturnObject("10000","无条件查询",bll.findForMap(values))));
        else{    
        	out.write(JSON.toJSONString(getReturnObject("10001","根据条件查询",bll.findForMap(values))));
        }
        
    }
    public void findByPage(JSONObject param) {
        List<Object> values=getConditionParam(param);//获取查询参数

        if (bll==null)
           out.write(JSON.toJSONString(getReturnObject("000000","系统没有提供业务对象",null)));

        Page result=bll.findByPage(values);
        if (result==null)
        {
            result=new Page();
            result.setPage(0);
            result.setTotal(0);
            List<Map<String, Object>> rows=new ArrayList<Map<String,Object>>();
            result.setRows(rows);
        }
        if (values==null || values.size()==0)
            out.write(JSON.toJSONString(getReturnObject("10000","无条件查询",result)));
        else
            out.write(JSON.toJSONString(getReturnObject("10001","根据条件查询",result)));
    }
    public void getMe(JSONObject param) {
        AbsSuperModel model=updateModel(initParameter(param));//获取客户端参数信息
        bll.setModel(model);
        out.write(JSON.toJSONString(getReturnObject("12","对象获取",bll.getMe())));
    }
}

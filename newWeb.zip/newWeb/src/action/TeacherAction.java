package action;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;
import util.JSONAndObject;
import bll.impl.TeacherServiceImpl;

public class TeacherAction extends SuperAction{
	public TeacherAction(){
		setBll(new TeacherServiceImpl());
	}

	@Override
	public List<Object> getConditionParam(JSONObject param) {
		// TODO Auto-generated method stub
		if (param==null) 
			 return  null;//判断条件是否为空param是页面传递的值
	     List<Object> values=new ArrayList<Object>();
	     if (JSONAndObject.GetJsonStringValue(param,"name")!=null)
	     {	     
	        	String page = JSONAndObject.GetJsonStringValue(param,"pageNumber");
	            String pageSzie  = JSONAndObject.GetJsonStringValue(param,"rowsCount");
	        	values.add(JSONAndObject.GetJsonStringValue(param,"name"));
	        	//查询语句过滤的行数
	            values.add(Integer.valueOf(page)*Integer.valueOf(pageSzie));
	            //一页显示的行数
	            values.add(Integer.valueOf(pageSzie));
	     }
	     return values;
	}
	
}

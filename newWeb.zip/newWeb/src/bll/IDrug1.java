package bll;

public interface IDrug1 {

}

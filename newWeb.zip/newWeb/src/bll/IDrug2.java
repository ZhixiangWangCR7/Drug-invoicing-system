package bll;

public interface IDrug2 {

}

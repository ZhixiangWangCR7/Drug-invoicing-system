package bll;

public interface IDrug3 {

}

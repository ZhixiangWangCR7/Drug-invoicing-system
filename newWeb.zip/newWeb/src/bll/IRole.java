package bll;

public interface IRole {

}

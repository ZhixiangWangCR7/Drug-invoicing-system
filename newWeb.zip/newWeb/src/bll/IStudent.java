package bll;

public interface IStudent {

}

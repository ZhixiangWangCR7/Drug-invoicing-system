package bll;

public interface ITeacher {

}

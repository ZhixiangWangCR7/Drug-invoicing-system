package bll;

public interface IUser {

}


package bll;

import java.util.List;
import java.util.Map; 

import dal.IDoData; 
import model.AbsSuperModel;
import model.Page;

public abstract class SuperService {
	private AbsSuperModel model=null;//实体对象
	private IDoData dal=null;//数据访问层对象
	public AbsSuperModel getModel() {
		return model;
	}
	public void setModel(AbsSuperModel model) {
		this.model = model;
	}
	public IDoData getDal() {
		return dal;
	}
	public void setDal(IDoData dal) {
		this.dal = dal;
	}
	/*新增操作*/
    public int save(){
      if (model==null || dal==null) return 0;
      return dal.save(model);
    }
    /*批量新增操作*/
    public int batchSave(List objs)
    {
      if (objs==null || objs.size()==0 || dal==null) return 0;
      return dal.batchSave(objs);
    }
    /*批量修改操作*/
    public int batchUpdate(List objs)
    {
    	if (objs==null || objs.size()==0 || dal==null) return 0;
        return dal.batchUpdate(objs);
    }
    /*更新操作*/
    public int update()
    {
    	if (model==null || dal==null) return 0;
        return dal.update(model);
    }
    /*删除操作*/
    public int delete()
    {
    	if (model==null || dal==null) return 0;
        return dal.delete(model);
    }
    /*批量删除操作*/
    public int batchDelete(List objs)
    {
    	if (objs==null || objs.size()==0 || dal==null) return 0;
        return dal.batchDelete(objs);
    }
    /*查找当前对象*/
    public Object getMe()
    {
    	if (model==null || dal==null) return null;
        return dal.getMe(model);
    }
    /*查找对象ID的数据是否在使用中*/
    public Boolean objectInUse()
    {
    	if (model==null || dal==null) return false;
        return dal.objectInUse(model.getId());
    }
    /*查找符合条件values的对象,以List的Map形式返回*/
    public List<Map<String,Object>> findForMap(List<Object> values)
    {
    	if (dal==null) return null;
    	return dal.findForMap(values);
    }
    /*查找符合条件values的对象,以List的对象形式返回*/
    public List<?> find(List<Object> values)
    {
    	if (dal==null) return null;
    	return dal.findForMap(values);
    }
    /*查找符合条件values的数据*/
    public Page findByPage(List<Object> values)
    {
    	System.out.println("superService--findByPage");
    	if (dal==null) return null;
    	  //DStudent
    	return dal.findByPage(values);
    } 
    public int getRowsCount(List<Object> values){
    	if (dal==null) 
    		return 0;
    	return dal.getRowsCount(values);
    }
}

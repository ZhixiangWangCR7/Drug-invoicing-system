package bll.impl;

import bll.IDrug1;
import bll.SuperService;
import dal.impl.DDrug1;
import model.Drug1;

public class Drug1ServiceImpl extends SuperService implements IDrug1 {
	public Drug1ServiceImpl() {
		setDal(new DDrug1());
		setModel(new Drug1());
	  }

	  public Drug1ServiceImpl(Drug1 drug)
	  {
	      setModel(drug);
	      setDal(new DDrug1());
	  }
}

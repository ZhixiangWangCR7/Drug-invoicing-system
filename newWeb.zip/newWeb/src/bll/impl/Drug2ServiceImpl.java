package bll.impl;

import bll.IDrug2;
import bll.SuperService;
import dal.impl.DDrug1;
import dal.impl.DDrug2;
import model.Drug1;
import model.Drug2;

public class Drug2ServiceImpl extends SuperService implements IDrug2 {
	
	public Drug2ServiceImpl() {
		setDal(new DDrug2());
		setModel(new Drug2());
	  }

	  public Drug2ServiceImpl(Drug2 drug)
	  {
	      setModel(drug);
	      setDal(new DDrug2());
	  }

}

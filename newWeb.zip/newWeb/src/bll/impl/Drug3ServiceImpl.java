package bll.impl;

import bll.IDrug3;
import bll.SuperService;
import dal.impl.DDrug2;
import dal.impl.DDrug3;
import model.Drug2;
import model.Drug3;

public class Drug3ServiceImpl extends SuperService implements IDrug3 {
	
	public Drug3ServiceImpl() {
		setDal(new DDrug3());
		setModel(new Drug3());
	  }

	  public Drug3ServiceImpl(Drug3 drug)
	  {
	      setModel(drug);
	      setDal(new DDrug3());
	  }

}

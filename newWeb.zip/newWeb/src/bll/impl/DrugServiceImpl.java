package bll.impl;

import bll.IDrug;
import bll.SuperService;
import dal.impl.DDrug;
import model.Drug;


public class DrugServiceImpl extends SuperService implements IDrug {
	public DrugServiceImpl() {
		setDal(new DDrug());
		setModel(new Drug());
	  }

	  public DrugServiceImpl(Drug drug)
	  {
	      setModel(drug);
	      setDal(new DDrug());
	  }
}

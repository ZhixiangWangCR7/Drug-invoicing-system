package bll.impl;

import bll.IUser;
import bll.SuperService;
import dal.impl.DLogin;
import model.User;

public class LoginServiceImpl extends SuperService implements IUser {
	public LoginServiceImpl() {
		setDal(new DLogin());
		setModel(new User());
	  }

	  public LoginServiceImpl(User user)
	  {
	      setModel(user);
	      setDal(new DLogin());
	  }
}

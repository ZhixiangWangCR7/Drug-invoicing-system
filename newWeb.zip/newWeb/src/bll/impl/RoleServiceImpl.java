package bll.impl;

import bll.IRole;
import bll.SuperService;
import dal.impl.DRole;
import model.Role;


public class RoleServiceImpl extends SuperService implements IRole {
	public RoleServiceImpl() {
		setDal(new DRole());
		setModel(new Role());
	  }

	  public RoleServiceImpl(Role role)
	  {
	      setModel(role);
	      setDal(new DRole());
	  }
}

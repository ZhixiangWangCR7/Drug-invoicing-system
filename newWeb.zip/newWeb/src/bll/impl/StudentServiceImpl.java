package bll.impl;

import dal.impl.DStudent;
import bll.IStudent;
import bll.SuperService;
import model.Student;

public class StudentServiceImpl extends SuperService implements IStudent {
  public StudentServiceImpl() {
	setDal(new DStudent());
	setModel(new Student());
  }

  public StudentServiceImpl(Student stu)
  {
      setModel(stu);
      setDal(new DStudent());
  }

}

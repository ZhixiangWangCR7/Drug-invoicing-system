package bll.impl;

import model.Teacher;
import dal.impl.DTeacher;
import bll.ITeacher;
import bll.SuperService;

public class TeacherServiceImpl extends SuperService implements ITeacher{
	 
	
	public TeacherServiceImpl() {
		    setModel(new Teacher());
			setDal(new DTeacher());
			
     }
}

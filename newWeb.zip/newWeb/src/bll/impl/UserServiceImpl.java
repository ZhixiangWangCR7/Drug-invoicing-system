package bll.impl;

import bll.SuperService;
import bll.IUser;
import dal.impl.DUser;
import model.User;

public class UserServiceImpl extends SuperService implements IUser {

	 public UserServiceImpl() {
		setDal(new DUser());
		setModel(new User());
	  }

	  public UserServiceImpl(User user)
	  {
	      setModel(user);
	      setDal(new DUser());
	  }

	

}



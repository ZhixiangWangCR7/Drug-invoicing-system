package dal;
//计划生育
public class DB extends DBHelper {
  private static DB sql=null;
  private DB(){}
  /*获取一个数据库访问对象*/
  public static DB GetInstance()
  {
	  if (sql==null)
		  sql=new DB();
	  return sql;
  }
}

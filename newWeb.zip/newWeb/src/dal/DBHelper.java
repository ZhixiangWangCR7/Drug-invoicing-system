package dal;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;

import model.Page;
 

/***********************************
 * className:数据库访问类
 * description:实现数据库的CRUD的操作，
 *             并支持事务、存储过程操作。
 * createDate:2017-11-8 10:32
 * author:王平华
 * version:1.0.0.0
 ************************************/
public abstract class DBHelper {
	private BasicDataSource dataSource=null;
	private Logger log=Logger.getLogger(DBHelper.class);
	/*连接数据库数据源初始化，需要common-pool和dbcp中间件支持*/
	private void init(){
		Properties dbprops=new Properties();
		//取配置文件可以根据实际的不同修改
		try { 
	      dbprops.load(DBHelper.class.getClassLoader().getResourceAsStream("resource/db.properties"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			String driverClassName=dbprops.getProperty("jdbc.driver");
			String url=dbprops.getProperty("jdbc.url");
			String username=dbprops.getProperty("jdbc.user");
			String password=dbprops.getProperty("jdbc.password");
			
			String initialSize=dbprops.getProperty("dataSource.initialSize");
			String minIdle=dbprops.getProperty("dataSource.minIdle");
			String maxIdle=dbprops.getProperty("dataSource.maxIdle");
			String maxWait=dbprops.getProperty("dataSource.maxWait");
			String maxActive=dbprops.getProperty("dataSource.maxActive");
			
			dataSource =new BasicDataSource();
			dataSource.setDriverClassName(driverClassName);
			dataSource.setUrl(url);
			dataSource.setUsername(username);
			dataSource.setPassword(password);
			
			//初始化连接数
			if(initialSize!=null){
				dataSource.setInitialSize(Integer.parseInt(initialSize));
			}
			//最小空闲连接
			if(minIdle!=null){
				dataSource.setMinIdle(Integer.parseInt(minIdle));
			}
			//最大空闲连接
			if(maxIdle!=null){
				dataSource.setMaxIdle(Integer.parseInt(maxIdle));
			}
			//超时回收时间（以毫秒为单位）
			if(maxWait!=null){
				dataSource.setMaxWait(Long.parseLong(maxWait));
			}
			//最大连接数
			if(maxActive!=null){
				if(!maxActive.trim().equals("0")){
					dataSource.setMaxActive(Integer.parseInt(maxActive));
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace(); 
			log.info("创建连接池失败！请检查设置！！！");
		}
	}
	/*实现指令对象的参数设置*/
	private void setPreparedStatementParam(PreparedStatement pstmt, List<Object> paramList) throws Exception {
		if(pstmt == null || paramList == null || paramList.isEmpty()) {
			return;
		}
		DateFormat df = DateFormat.getDateTimeInstance();
		for (int i = 0; i < paramList.size(); i++) {
			if(paramList.get(i) instanceof Integer) {
				int paramValue = ((Integer)paramList.get(i)).intValue();
				pstmt.setInt(i+1, paramValue);
			} else if(paramList.get(i) instanceof Float) {
				float paramValue = ((Float)paramList.get(i)).floatValue();
				pstmt.setFloat(i+1, paramValue);
			} else if(paramList.get(i) instanceof Double) {
				double paramValue = ((Double)paramList.get(i)).doubleValue();
				pstmt.setDouble(i+1, paramValue);
			} else if(paramList.get(i) instanceof Date) {
				pstmt.setString(i+1, df.format((Date)paramList.get(i)));
			} else if(paramList.get(i) instanceof Long) {
				long paramValue = ((Long)paramList.get(i)).longValue();
				pstmt.setLong(i+1, paramValue);
			} else if(paramList.get(i) instanceof String) {
				pstmt.setString(i+1, (String)paramList.get(i));
			}else {
				pstmt.setObject(i+1, paramList.get(i));
			}
		}
		return;
	}
	/*获取数据库的连接对象*/
	public synchronized Connection getConnection() {
		if(dataSource==null){
			init();
		} 
		Connection con=null;
		if(dataSource!=null){			
			try {
				con=dataSource.getConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				con=null;
				log.info("数据库连接对象构建失败，请核实！");
			}
		}
		return con;
	}
	/**
	 * 关闭数据库连接
	 * @param conn
	 */
	private void closeConn(Connection conn) {
		if(conn == null) {
			return;
		}
		try {
			conn.close();
		} catch (SQLException e) {
			//log.info(e.getMessage());
		}
	}
	
	/**
	 * 关闭
	 * @param stmt
	 */
	private void closeStatement(Statement stmt) {
		if(stmt == null) {
			return;
		}
		try {
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
			//log.info(e.getMessage());
		}
	}
	
	/**
	 * 关闭
	 * @param rs
	 */
	private void closeResultSet(ResultSet rs) {
		if(rs == null) {
			return;
		}
		try {
			rs.close();
		} catch (SQLException e) {
			//log.info(e.getMessage());
		}
 
	}
	/*****************************************************
	 * 功能：根据字符串指令，获取指令执行对象
	 * 参数：cmd数据库操作字符串指令
	 *****************************************************/
	public PreparedStatement getStatement(String cmd) throws SQLException
	{ 
		 	Connection con=getConnection(); 
			if (con==null || cmd.equals("")) return null;
			return con.prepareStatement(cmd);  

	}
	/*****************************************************
	 * 功能：数据库指令执行，返回执行结果，通常实现增删改
	 * 参数：cmd数据库操作字符串指令
	 * 返回值：指令执行结果，大于0表示成功，其他表示失败
	 *****************************************************/
	public int command(String cmd)
	{
		Connection con=getConnection();
        PreparedStatement ps=null;
		if (con==null) return 0;
		try
		{  
			System.out.println(cmd);
			
			ps=con.prepareStatement(cmd);//
			 
			return ps.executeUpdate();  
		}catch(Exception ex)
		{
			ex.printStackTrace();
			return 0;
		}finally
		{
			closeStatement(ps);
			closeConn(con);
		}
	}
    
	/**************************
	 * 方法名：command;
	 * 功能描述：实现带参数的操作，例如：insert into 表名称(a,b,c) values (?,?,?)
	 * @return:大于0表示成果，否则表示失败
	 ***************************/
	public int command(String cmd,List<Object> values)
	{ 	 
		if (values==null || values.size()==0) return 0;	 
		Connection con=getConnection();
        PreparedStatement ps=null;
		try
		{  
			con=getConnection();
			if (con==null) return 0;
			ps=con.prepareStatement(cmd);
			 
			setPreparedStatementParam(ps, values);
			 
			 

			return ps.executeUpdate();  
		}catch(SQLException ex)
		{
			ex.printStackTrace();
			return 0;
		}catch (Exception e) {
			e.printStackTrace();
			//log.info(cmd+",命令参数解析失败！");
			return 0;
		}
		finally
		{  	 
			closeStatement(ps);
			closeConn(con);
		}
	} 
    /*字符串指令批量操作*/
	public int command(String[] cmd)
	{  
		if (cmd==null || cmd.length==0) return 0;
		Connection con=getConnection();
        Statement ps=null;
		try
		{  
			con.setAutoCommit(false);   
			ps=con.createStatement();//创建操作对象
			for(int i=0;i<cmd.length;i++)
				ps.addBatch(cmd[i]);
			ps.executeBatch();
			con.commit();
			return ps.getUpdateCount(); 
		}catch(SQLException ex)
		{

			try {
				con.rollback();
				con.setAutoCommit(true); 
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
			ex.printStackTrace();
			return 0;
		}
		finally{
			closeStatement(ps);
			closeConn(con);
		}
	}

	public int command(String[] cmd,List<List<Object>> values)
	{		 
		if (cmd==null || cmd.length==0) return 0;
		Connection con=getConnection();
        Statement ps=null;
		try
		{
			con=getConnection(); 
			con.setAutoCommit(false);   
			ps=con.createStatement();
			for(int i=0;i<cmd.length;i++)
			{  
				ps.addBatch(cmd[i]); 
			}
			ps.executeBatch();
			con.commit();
			return ps.getUpdateCount(); 
		}catch(SQLException ex)
		{
			try {

				con.rollback();
				con.setAutoCommit(true);				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
			ex.printStackTrace();
			return 0;
		}
		finally{ 
			closeStatement(ps);
			closeConn(con);
		}
	}
	public int command(List<String> lCmd)
	{		
		if (lCmd==null || lCmd.size()==0) return 0;	
		Connection con=getConnection();
        Statement ps=null;
		try
		{  
			con.setAutoCommit(false);   
			ps=con.createStatement();
			for(int i=0;i<lCmd.size();i++)
			{	
				System.out.println(lCmd.get(i));
				ps.addBatch(lCmd.get(i));
			}
			ps.executeBatch();
			con.commit();
			return ps.getUpdateCount(); 
		}catch(SQLException ex)
		{
			try {
				con.rollback();
				con.setAutoCommit(true);				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
			ex.printStackTrace();
			return 0;
		}
		finally{
			closeStatement(ps);
			closeConn(con);
		}
	}
	/**************************
	*数据库指令操作
	 ***************************/
	public int command(PreparedStatement cmd)
	{
		if (cmd==null) return 0;
		try
		{				
			return cmd.executeUpdate();  
		}catch(SQLException ex)
		{
			ex.printStackTrace();
			return 0;
		}finally
		{
			try
			{
				cmd.close();
				cmd.getConnection().close();  
			}catch(SQLException e)
			{
				e.printStackTrace();
			}

		}
	}
	/**************************
	 * 数据查找
	 ***************************/
	public ResultSet find2(String cmd)
	{  
		Connection con=getConnection();
        PreparedStatement ps=null;
        ResultSet rs=null;
		try
		{ 	 
			con=getConnection();
			ps= con.prepareStatement(cmd);
			rs=ps.executeQuery(); 
			if (rs.next()==false) 
				return null;
			else
				rs.previous();
			return rs;	  	  
		}catch(SQLException ex)
		{
			ex.printStackTrace();
			return null;
		} 
		finally
		{  

		}
	}
	private List<Map<String, Object>> getQueryList(ResultSet rs) throws Exception {
		if(rs == null) {
			return null;
		}
		ResultSetMetaData rsMetaData = rs.getMetaData();
		int columnCount = rsMetaData.getColumnCount();
		List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();
		while (rs.next()) {
			Map<String, Object> dataMap = new HashMap<String, Object>();
			for (int i = 0; i < columnCount; i++) {
				dataMap.put(rsMetaData.getColumnName(i+1), rs.getObject(i+1));
			}
			dataList.add(dataMap);
		}
		return dataList;
	}

	public List<Map<String,Object>> find(String cmd)
	{ 	 
		Connection con=getConnection();
        PreparedStatement ps=null;
        ResultSet rs=null;
		if (con==null) return null;
		if(cmd == null || cmd.trim().equals("")) {
			//log.info("parameter is valid!");
			return null;
		} 
		//log.info("查询指令："+cmd);
		List<Map<String, Object>> queryList = null;
		try { 
			 
			ps = con.prepareStatement(cmd); 
			if(ps == null) {
				return null;
			}
			rs = ps.executeQuery();
			try {
				queryList = getQueryList(rs);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				queryList=null;
				e.printStackTrace();
			}
		} catch (SQLException e) {
			//log.info(e.getMessage());
			System.out.println("数据查询处理异常!");
			 
		} finally {
			closeResultSet(rs);
			closeStatement(ps);
			closeConn(con);
		}
		return queryList;
 
	}
	public List<Map<String,Object>> findByParam(String cmd,List<Object> conValues)
	{ 	 
		Connection con=getConnection();
        PreparedStatement ps=null;
        ResultSet rs=null;
		if (con==null) return null;
		if(cmd == null || cmd.trim().equals("")) {
			//log.info("parameter is valid!");
			return null;
		} 
		 
		List<Map<String, Object>> queryList = null;
		try { 
			 
			ps = con.prepareStatement(cmd); 
			setPreparedStatementParam(ps, conValues);
			if(ps == null) {
				return null;
			}
			rs = ps.executeQuery();
			try {
				queryList = getQueryList(rs);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				queryList=null;
				e.printStackTrace();
			}
		} catch (SQLException e) {
			//log.info(e.getMessage());
			System.out.println("数据查询处理异常!");
			 
		}catch (Exception e) {
			// TODO: handle exception
			//log.info(cmd+";查询条件参数解析错误！");
		}
		finally {
			closeResultSet(rs);
			closeStatement(ps);
			closeConn(con);
		}
		return queryList;
 
	}
	
	public List<Map<String,Object>> find_ex(String cmd)
	{ 	 
		Connection con=getConnection();
        PreparedStatement ps=null;
        ResultSet rs=null;
		if (con==null) return null;
		
		try
		{
			ps=con.prepareStatement(cmd,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);//??????????
			System.out.println(cmd);
			rs=ps.executeQuery(); 
			if (rs.next()==false) 
				return null;
			else
			{
				rs.previous();
				ResultSetMetaData rsMetaData = rs.getMetaData();
				int columnCount = rsMetaData.getColumnCount();
				List<Map<String,Object>> lTemp=new ArrayList<Map<String,Object>>();

				while(rs.next())
				{
					Map<String,Object> mTemp=new HashMap<String,Object>();
					int i=1;
					while(i<=columnCount)
					{
						mTemp.put(rsMetaData.getColumnName(i), rs.getObject(i++));
					}
					lTemp.add(mTemp);
				} 
				return lTemp;
			}   	  
		}catch(SQLException ex)
		{
			ex.printStackTrace();
			return null;
		}finally
		{
			closeResultSet(rs);
			closeStatement(ps);
			closeConn(con);

		}
	}
    /**********************************************************
     * 将ResultSet转换成List
     *************************************************************/
	private List<Map<String,Object>> resultToList(ResultSet rsTemp)
	{
		if (rsTemp==null) return null;
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		
		int columnCount=0;
		try {
			ResultSetMetaData md = rsTemp.getMetaData();
			columnCount = md.getColumnCount();
			while (rsTemp.next()) { 
				Map<String,Object> rowData = new HashMap<String,Object>();
				for (int i = 1; i <= columnCount; i++) {
					rowData.put(md.getColumnName(i), rsTemp.getObject(i));
				    
				}  
				list.add(rowData); 
			} 
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} 
		catch (Exception ex)
		{
			return null;
		}
			
	}
	public List<Map<String,Object>> find1(String cmd)
	{  
		Connection con=getConnection();
        PreparedStatement ps=null;
        ResultSet rs=null;
		try
		{  	
			ps=con.prepareStatement(cmd,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);//����������
			rs=ps.executeQuery(); 
			 
			return resultToList(rs);	  	  
		}catch(SQLException ex)
		{
			ex.printStackTrace();
			return null;
		} 
		finally
		{  
			closeResultSet(rs);
			closeStatement(ps);
			closeConn(con);
		}
	}
	/*问号条件参数*/
	public ResultSet find(String cmd,List<Object> conValues)
	{ 
		Connection con=getConnection();
        PreparedStatement ps=null;
		try
		{ 	 
			ps=con.prepareStatement(cmd,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);//����������
			if (conValues!=null && conValues.size()>0)
				for(int i=0;i<conValues.size();i++)
					ps.setObject(i+1, conValues.get(i));
			ResultSet rs=ps.executeQuery();
			if (rs.next()==false) 
				return null;
			else
				rs.previous();
			return rs;	  	  
		}catch(SQLException ex)
		{
			ex.printStackTrace();
			return null;
		} 
		finally{

		}
	}
	/*查找符合记录的总行数*/
	public int  findRowsCount(String tableName,String condition)
	{
		Connection con=getConnection();
        PreparedStatement ps=null;
        ResultSet rs=null;
		if (condition.trim()=="") condition="1=1";

		String cmd="SELECT count(*) total FROM "+tableName+" WHERE "+condition;
        //log.info(cmd);
		try
		{
			 
			ps=con.prepareStatement(cmd,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);//����������
			rs=ps.executeQuery();
			if (rs.next()==false) 
				return 0;
			else
				return rs.getInt("total");

		}catch(SQLException ex)
		{
			return 0;
		} 
		finally{
			closeResultSet(rs);
          closeStatement(ps);
          closeConn(con);
          
		}
	}
	/*查找符合记录的总行数*/
	public int  findRowsCount(String tableName,String condition,List<Object> values)
	{
		Connection con=getConnection();
        PreparedStatement ps=null;
        ResultSet rs=null;
		if (condition.trim()=="") condition="1=1";

		String cmd="SELECT count(*) total FROM "+tableName+" WHERE "+condition;
        //log.info(cmd);
		try
		{
			 
			ps=con.prepareStatement(cmd,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);//����������
			setPreparedStatementParam(ps, values);
			rs=ps.executeQuery();
			if (rs.next()==false) 
				return 0;
			else
				return rs.getInt("total");

		}catch(SQLException ex)
		{
			return 0;
		}catch (Exception e) {
			// TODO: handle exception
			//log.info("参数解析错误");
			return 0;
		} 
		finally{
			closeResultSet(rs);
          closeStatement(ps);
          closeConn(con);
          
		}
	}
	/*查找符合记录的总行数*/
	public int  findRowsCountByGroup(String tableName,String condition,String groupField)
	{
		Connection con=getConnection();
        PreparedStatement ps=null;
        ResultSet rs=null;
		if (condition.trim()=="") condition="1=1";

		String cmd="";
		if (groupField.trim().equals(""))
			cmd="SELECT count(*) total FROM "+tableName+" WHERE "+condition;
		else
			cmd="select count(*) total from(SELECT count(*) total FROM "+tableName+" WHERE "+condition+" group by "+groupField+") table_alis";

		try
		{
			con=getConnection();
			ps=con.prepareStatement(cmd,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);//����������
			rs=ps.executeQuery();
			if (rs.next()==false) 
				return 0;
			else
				return rs.getInt("total");

		}catch(SQLException ex)
		{
			return 0;
		} 
		finally{
           closeResultSet(rs);
           closeStatement(ps);
           closeConn(con);
		}
	}
	/**************************
	 * name:findbyPage
	 * @description:find data by page,but no order by statement;
	 * @param cols:columns expression,for exmaple select * from test where name=? *
	 * @param tableName:table's name
	 * @param condition:find need condition
	 * @param page:page code,from start 0
	 * @param rows:display rows by per page
	 ***************************/
	public Page findByPage(String cols,String tableName,String condition,List<Object> conValues,int page,int rows)
	{
		Connection con=getConnection();
        PreparedStatement ps=null;
        ResultSet rs=null;		 
		String cmd="select table_b.* from (SELECT (@rownum:= @rownum+1) AS rowno,table_alias.*  FROM (SELECT  "+cols+" FROM (select @rownum:=0) r,"+tableName+"  WHERE "+condition+") table_alias) table_b WHERE table_b.rowno >"+page*rows+" and table_b.rowno<= "+(page*rows+rows);
		//log.info(cmd);
		try
		{
			con=getConnection();
			ps=con.prepareStatement(cmd,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);//����������
			setPreparedStatementParam(ps, conValues);
			rs=ps.executeQuery();
			if (rs.next()==false) 
				return null;
			else
			{	
				rs.previous();
			Page data=new Page();
			data.setPage(page);
			data.setPageRows(rows);
			data.setTotal(findRowsCount(tableName, condition,conValues));
			data.setRows(resultToList(rs));
			return data;
			}
		}catch(SQLException ex)
		{
			ex.printStackTrace();
			return null;
		}catch (Exception e) {
			//log.info("分页查询参数解析错误");
			return null;
		} 
		finally{
           closeResultSet(rs);
           closeStatement(ps);
           closeConn(con);
		}
	}
	/**************************
	 * name:findbyPage
	 * @description:find data by page,but no order by statement;
	 * @param cols:columns string,example a,b...or *
	 * @param tableName:table's name
	 * @param condition:find need condition
	 * @param page:page code,from start 0
	 * @param rows:display rows by per page
	 ***************************/
	public List<Map<String,Object>> findByPage(String cols,String tableName,String condition,int page,int rows)
	{
		page=page-1;
		Connection con=getConnection();
        PreparedStatement ps=null;
        ResultSet rs=null;
		if (condition.trim()=="") condition="1=1";
		//if (cols=="*") cols="t.*";
		String cmd="select * from (SELECT ROWNUM AS rowno,table_alias.*  FROM (SELECT  "+cols+" FROM "+tableName+"  WHERE "+condition+") table_alias) WHERE rowno >"+page*rows+" and rowno<= "+(page*rows+rows);
		System.out.println(cmd); 
		try
		{
			con=getConnection();
			ps=con.prepareStatement(cmd,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);//����������
			rs=ps.executeQuery();
			if (rs.next()==false) 
				return null;
			else
				rs.previous();
			return resultToList(rs);	  	  
		}catch(SQLException ex)
		{
			ex.printStackTrace();
			return null;
		} 
		finally{
           closeResultSet(rs);
           closeStatement(ps);
           closeConn(con);
		}
	}

	public ResultSet findByPageGroupOrder(String cols,String tableName,String condition,int page,int rows,String groupFields,String orderFields)
	{
		if (condition.trim()=="") condition="1=1";
		if (cols=="*") cols="t.*";
		String cmd="select * from(SELECT ROWNUM AS rowno,table_alias.*  FROM (SELECT "+cols+" FROM "+tableName+" t WHERE "+condition+" group by "+groupFields+" order by "+orderFields+") table_alias) bb WHERE bb.rowno >"+page*rows +" and bb.rowno <= "+(page*rows+rows);

		Connection con=getConnection();
        PreparedStatement ps=null;
        ResultSet rs=null;
		try
		{
			con=getConnection();
			ps=con.prepareStatement(cmd,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);//����������
			rs=ps.executeQuery();
			if (rs.next()==false) 
				return null;
			else
				rs.previous();
			return rs;	  	  
		}catch(SQLException ex)
		{
			ex.printStackTrace();
			return null;
		} 
		finally
		{
			 closeResultSet(rs);
			 closeStatement(ps);
			 closeConn(con);

		}
	}
	/**************************
	 * name:findbyPage
	 * @description:find data by page,but no order by statement;
	 * @param cols:columns string,example a,b...or *
	 * @param tableName:table's name
	 * @param condition:find need condition
	 * @param orderCols:order by need fields
	 * @param asc:if asc then true,descend is false
	 * @param page:page code,from start 0
	 * @param rows:display rows by per page
	 ***************************/
	public ResultSet findByPageOrder(String cols,String tableName,String condition,String orderCols,boolean asc,int page,int rows)
	{
		if (condition.trim()=="") condition="1=1";
		String cmd="";
		if (asc)
			cmd="SELECT *  FROM (SELECT ROWNUM AS rowno, cols FROM "+tableName+" t WHERE "+condition+" and ROWNUM <= "+(page*rows+rows)+" order by "+orderCols+" asc) table_alias WHERE table_alias.rowno >"+page*rows;
		else
			cmd="SELECT *  FROM (SELECT ROWNUM AS rowno, cols FROM "+tableName+" t WHERE "+condition+" and ROWNUM <= "+(page*rows+rows)+" order by "+orderCols+" desc) table_alias WHERE table_alias.rowno >"+page*rows;
		Connection con=getConnection();
        PreparedStatement ps=null;
        ResultSet rs=null;
		try
		{
			con=getConnection();
			ps=con.prepareStatement(cmd,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);//����������
			rs=ps.executeQuery();
			if (rs.next()==false) 
				return null;
			else
				rs.previous();
			return rs;	  	  
		}catch(SQLException ex)
		{
			return null;
		}
		finally{
			 closeResultSet(rs);
			 closeStatement(ps);
			 closeConn(con);
		}
	}


	/*
	 * 获得数据库中的一列字符串
	 */

	public ResultSet _find(String cmd){
		Connection con=getConnection();
        PreparedStatement ps=null;
        ResultSet rs=null;
		try
		{  
			ps=con.prepareStatement(cmd);
			rs=ps.executeQuery();
			if (rs!=null) 
				return rs;
			return null;
		}catch(SQLException ex)
		{
			return null;
		} finally{

		}
	}


	/**********************************
	 *查找
	 ***********************************/
	public ResultSet find(PreparedStatement cmd)
	{ 
		try
		{	
			if (cmd==null) return null;
			return cmd.executeQuery();		  
		}catch(SQLException ex)
		{
			return null;
		}finally
		{

		} 
	}
	/************************************
	 *支持存储过程指令执行
	 *@param name:存储过程名
	 *@param param:值
	 ***********************************/
	public int commandByPRC(String name,String param)
	{ 
		CallableStatement cs=null;
		Connection con=getConnection();
         
		try
		{
			con=getConnection(); 
			cs=con.prepareCall("{? =call "+name+"(?)}");
			cs.setString(2, param); 
			cs.registerOutParameter(1, java.sql.Types.INTEGER); 
			cs.execute(); 
			return cs.getInt(1);

		}catch(SQLException ex)
		{  
			System.out.println(ex.toString());
			return -1;
		} finally
		{ 
			closeConn(con);
		}
	}

	public int commandByPRC(String name,String[] param)
	{  
		CallableStatement cs=null;
		Connection con=getConnection();
        
		try
		{
			con=getConnection(); 
			String strTemp="";
			if (param!=null && param.length>0)
			{
				for(int i=0;i<param.length;i++)
				{
					if (strTemp=="")
						strTemp="?";
					else {
						strTemp+=",?";
					}
				}
			}

			cs=con.prepareCall("{? =call "+name+"("+strTemp+")}");
			if (param!=null && param.length>0)
			{
				for(int i=1;i<param.length;i++)
					cs.setString(i+1, param[i-1]); 	

			}

			cs.registerOutParameter(1, java.sql.Types.INTEGER); 
			cs.execute(); 
			return cs.getInt(1);

		}catch(SQLException ex)
		{  
			System.out.println(ex.toString());
			return -1;
		} finally{
			closeConn(con);
		}
	}

	/****************************************************
	 * 存储过程查找
	 ***************************************************/
	public ResultSet findByPRC(String name,String param)
	{

		CallableStatement cs=null; 
		Connection con=getConnection();
        
		try
		{
			con=getConnection(); 
			cs=con.prepareCall("{call "+name+"(?)}");
			cs.setString(1, param);		  
			return cs.executeQuery();

		}catch(SQLException ex)
		{
			ex.printStackTrace();
			return null;
		} finally
		{
			closeConn(con);
		}

	}

}

package dal;

public interface IDrug extends IDoData {

}

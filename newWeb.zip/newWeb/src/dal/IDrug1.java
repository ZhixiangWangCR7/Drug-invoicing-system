package dal;

public interface IDrug1 extends IDoData {

}

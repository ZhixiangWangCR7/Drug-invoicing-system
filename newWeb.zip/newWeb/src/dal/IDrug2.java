package dal;

public interface IDrug2 extends IDoData {

}

package dal;

public interface IDrug3 extends IDoData {

}

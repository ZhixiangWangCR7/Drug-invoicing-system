package dal;

public interface IRole extends IDoData {

}

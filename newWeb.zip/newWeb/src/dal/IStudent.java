package dal;

public interface IStudent extends IDoData {

}

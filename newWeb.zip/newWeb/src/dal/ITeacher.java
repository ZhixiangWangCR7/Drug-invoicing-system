package dal;

public interface ITeacher extends IDoData{

}

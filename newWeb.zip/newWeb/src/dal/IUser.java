package dal;

public interface IUser extends IDoData{
   
}


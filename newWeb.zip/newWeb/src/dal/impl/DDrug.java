package dal.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import dal.DB;
import dal.IDrug;
import model.Drug;
import model.Page;

public class DDrug implements IDrug {

	@Override
	public int save(Object obj) {
		if (obj==null || obj instanceof model.Drug==false) 
			return 0;//参数不合法
		Drug drug=(Drug)obj;
		String cmd="insert into drug (id,name,medType,unit,norm,area,buyPrice,bid,profit,createDate) values (?,?,?,?,?,?,?,?,?,?)";
		List<Object> values=new ArrayList<Object>();
		values.add(drug.getId());
		values.add(drug.getName());
		values.add(drug.getMedType());
		values.add(drug.getUnit());
		values.add(drug.getNorm());
		values.add(drug.getArea());
		values.add(drug.getBuyPrice());
		values.add(drug.getBid());
		values.add(drug.getProfit());
		values.add(drug.getCreateDate());
		
		DB sql=DB.GetInstance();
		return sql.command(cmd,values);
		 
	}

	@Override
	public int batchSave(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int batchUpdate(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Object obj) {
		Drug drug=(Drug)obj;
		String cmd="update drug set name=?,medType=?,unit=?,norm=?,area=?,buyPrice=?,bid=?,profit=? where id=?";
		List<Object> values=new ArrayList<Object>();
		values.add(drug.getName());
		values.add(drug.getMedType());
		values.add(drug.getUnit());
		values.add(drug.getNorm());
		values.add(drug.getArea());
		values.add(drug.getBuyPrice());
		values.add(drug.getBid());
		values.add(drug.getProfit());
		values.add(drug.getId());
		DB sql=DB.GetInstance();
		return sql.command(cmd,values);
	}

	@Override
	public int delete(Object obj) {
		if (obj==null || obj instanceof model.Drug==false) 
			return 0;//参数不合法
		Drug drug=(Drug)obj;
		String cmd="delete from drug where id=?";
		List<Object> values=new ArrayList<Object>();
		values.add(drug.getId());
		DB sql=DB.GetInstance();   	
		return sql.command(cmd, values);
	}

	@Override
	public int batchDelete(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getMe(Object obj) {
		// TODO Auto-generated method stub
		if (obj==null || obj instanceof model.Drug==false) 
			return 0;//参数不合法
		Drug drug=(Drug)obj;
		String cmd="select * from drug where id=?";
		List<Object> values=new ArrayList<Object>();
		values.add(drug.getId());
		DB sql=DB.GetInstance();
		return sql.findByParam(cmd,values).get(0);
	}

	@Override
	public Boolean objectInUse(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String,Object>> findForMap(List<Object> values) {
        DB sql=DB.GetInstance();    
		return sql.findByParam("select * from drug where name like ? limit ?,?", values);
	}

	@Override
	public List<?> find(List<Object> values) {
		// TODO Auto-generated method stub
		 DB sql=DB.GetInstance(); 
		 return sql.findByParam("select * from drug where name like %?% limit ?,?", values);
	}

    @Override
	public Page findByPage(List<Object> conValues) {
    	
    	// 参数
    	if (conValues==null || conValues.size()!=3) return  null;
		if (conValues.get(1) instanceof Integer==false) return null;
		if (conValues.get(2) instanceof Integer==false) return null;
		DB sql=DB.GetInstance();
		List<Object> values=new ArrayList<Object>();
		values.add("%"+conValues.get(0)+"%");//获取name条件值,特别提示，通配符必%须作为值传递，不可以放在？一起
		int page=(int)conValues.get(1);
		int rows=(int)conValues.get(2);
		return sql.findByPage("*","drug","name like ?",values,page,rows);
	}

    @Override
	public int getRowsCount(List<Object> values) {
		// TODO Auto-generated method stub
		return 0;
	} 


}

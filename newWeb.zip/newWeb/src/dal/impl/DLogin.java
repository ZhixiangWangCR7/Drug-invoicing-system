package dal.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import dal.DB;
import dal.IUser;
import model.Page;
import model.User;

public class DLogin implements IUser {

	@Override
	public int save(Object obj) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int batchSave(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int batchUpdate(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Object obj) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(Object obj) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int batchDelete(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getMe(Object obj) {
		// TODO Auto-generated method stub
		if (obj==null || obj instanceof model.User==false) 
			return 0;//参数不合法
		User user=(User)obj;
		String cmd="select * from user where number=? and passWord=?";
		List<Object> values=new ArrayList<Object>();
		values.add(user.getNumber());
		values.add(user.getPassWord());
		DB sql=DB.GetInstance();	
        Map<String, Object> o1=sql.findByParam(cmd,values).get(0);
			return o1;
	}
	

	@Override
	public Boolean objectInUse(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String, Object>> findForMap(List<Object> values) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<?> find(List<Object> values) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Page findByPage(List<Object> conValues) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getRowsCount(List<Object> values) {
		// TODO Auto-generated method stub
		return 0;
	}

}

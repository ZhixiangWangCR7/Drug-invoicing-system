package dal.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import dal.DB;
import dal.IRole;
import model.Page;
import model.Role;

public class DRole implements IRole {

	@Override
	public int save(Object obj) {
		if (obj==null || obj instanceof model.Role==false) 
			return 0;//参数不合法
		Role role=(Role)obj;
		String cmd="insert into role (id,name,power) values (?,?,?)";
		List<Object> values=new ArrayList<Object>();
		values.add(role.getId());
		values.add(role.getName());
		values.add(role.getPower());
		
		
		DB sql=DB.GetInstance();
		return sql.command(cmd,values);
		 
	}

	@Override
	public int batchSave(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int batchUpdate(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Object obj) {
		Role role=(Role)obj;
		String cmd="update role set name=?,power=? where id=?";
		List<Object> values=new ArrayList<Object>();
		values.add(role.getName());
		values.add(role.getPower());
		values.add(role.getId());
		DB sql=DB.GetInstance();
		return sql.command(cmd,values);
	}

	@Override
	public int delete(Object obj) {
		if (obj==null || obj instanceof model.Role==false) 
			return 0;//参数不合法
		Role role=(Role)obj;
		String cmd="delete from role where id=?";
		List<Object> values=new ArrayList<Object>();
		values.add(role.getId());
		DB sql=DB.GetInstance();   	
		return sql.command(cmd, values);
	}

	@Override
	public int batchDelete(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getMe(Object obj) {
		// TODO Auto-generated method stub
		if (obj==null || obj instanceof model.Role==false) 
			return 0;//参数不合法
		Role role=(Role)obj;
		String cmd="select * from role where id=?";
		List<Object> values=new ArrayList<Object>();
		values.add(role.getId());
		DB sql=DB.GetInstance();
		return sql.findByParam(cmd,values).get(0);
	}

	@Override
	public Boolean objectInUse(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String,Object>> findForMap(List<Object> values) {
        DB sql=DB.GetInstance();    
		return sql.findByParam("select * from role where name like ? limit ?,?", values);
	}

	@Override
	public List<?> find(List<Object> values) {
		// TODO Auto-generated method stub
		 DB sql=DB.GetInstance(); 
		 return sql.findByParam("select * from role where name like %?% limit ?,?", values);
	}

    @Override
	public Page findByPage(List<Object> conValues) {
    	
    	// 参数
    	if (conValues==null || conValues.size()!=3) return  null;
		if (conValues.get(1) instanceof Integer==false) return null;
		if (conValues.get(2) instanceof Integer==false) return null;
		DB sql=DB.GetInstance();
		List<Object> values=new ArrayList<Object>();
		values.add("%"+conValues.get(0)+"%");//获取name条件值,特别提示，通配符必%须作为值传递，不可以放在？一起
		int page=(int)conValues.get(1);
		int rows=(int)conValues.get(2);
		return sql.findByPage("*","role","name like ?",values,page,rows);
	}

    @Override
	public int getRowsCount(List<Object> values) {
		// TODO Auto-generated method stub
		return 0;
	} 
}

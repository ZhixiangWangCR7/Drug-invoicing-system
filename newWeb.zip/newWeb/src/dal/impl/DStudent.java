package dal.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import model.Page;
import model.Student;
import dal.DB; 
import dal.IStudent;

public class DStudent implements IStudent {

	@Override
	public int save(Object obj) {
		if (obj==null || obj instanceof model.Student==false) 
			return 0;//参数不合法
		Student student=(Student)obj;
		String cmd="insert into Student(id,name,number,createDate,age,tid) values (?,?,?,?,?,?)";
		List<Object> values=new ArrayList<Object>();
		values.add(student.getId());
		values.add(student.getName());
		values.add(student.getNumber());
		values.add(student.getCreateDate());
		values.add(student.getAge());
		values.add(student.getTid());
		
		DB sql=DB.GetInstance();
		return sql.command(cmd,values);
		 
	}

	@Override
	public int batchSave(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int batchUpdate(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Object obj) {
		Student student=(Student)obj;
		String cmd="update student set name=?,number=?,age=?,tid=? where id=?";
		List<Object> values=new ArrayList<Object>();
		values.add(student.getName());
		values.add(student.getNumber());
		values.add(student.getAge());
		values.add(student.getTid());
		values.add(student.getId());
		DB sql=DB.GetInstance();
		return sql.command(cmd,values);
	}

	@Override
	public int delete(Object obj) {
		if (obj==null || obj instanceof model.Student==false) 
			return 0;//参数不合法
		Student student=(Student)obj;
		String cmd="delete from student where id=?";
		List<Object> values=new ArrayList<Object>();
		values.add(student.getId());
		DB sql=DB.GetInstance();   	
		return sql.command(cmd, values);
	}

	@Override
	public int batchDelete(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getMe(Object obj) {
		// TODO Auto-generated method stub
		if (obj==null || obj instanceof model.Student==false) 
			return 0;//参数不合法
		Student student=(Student)obj;
		String cmd="select * from student_teacher where id=?";
		List<Object> values=new ArrayList<Object>();
		values.add(student.getId());
		DB sql=DB.GetInstance();
		Map<String, Object> o1=sql.findByParam(cmd,values).get(0);
		return o1;
	}

	@Override
	public Boolean objectInUse(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String,Object>> findForMap(List<Object> values) {
        DB sql=DB.GetInstance();  
        List<Map<String, Object>> o1= sql.findByParam("select * from teacher", values);
		return o1;
	}

	@Override
	public List<?> find(List<Object> values) {
		// TODO Auto-generated method stub
		 DB sql=DB.GetInstance(); 
		 return sql.findByParam("select * from student", values);
	}

    @Override
	public Page findByPage(List<Object> conValues) {	
    	// 参数
    	if (conValues==null || conValues.size()!=3) return  null;
		if (conValues.get(1) instanceof Integer==false) return null;
		if (conValues.get(2) instanceof Integer==false) return null;
		DB sql=DB.GetInstance();
		List<Object> values=new ArrayList<Object>();
		values.add("%"+conValues.get(0)+"%");//获取name条件值,特别提示，通配符必%须作为值传递，不可以放在？一起
		int page=(int)conValues.get(1);
		int rows=(int)conValues.get(2);
		//findByPage("*","student", name like ? ,values,page,rows)
		// select a.id,a.number,a.name,a.age,b.name from  student as a left join teacher as b on  a.tid=b.id where a.name like ?;   
		return sql.findByPage("a.id,a.number,a.createDate,a.name,a.age,b.name as teacherName","student as a left join teacher as b on a.tid=b.id","a.name like ?",values,page,rows);
	   
    }

    @Override
	public int getRowsCount(List<Object> values) {
		// TODO Auto-generated method stub
		return 0;
	} 
}

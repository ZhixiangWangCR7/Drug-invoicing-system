package dal.impl;

import java.util.List;
import java.util.Map;
import model.Page;
import dal.ITeacher;

public class DTeacher implements ITeacher {
	
	public int save(Object obj) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int batchSave(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int batchUpdate(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int update(Object obj) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int delete(Object obj) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int batchDelete(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	public Object getMe(Object obj) {
		// TODO Auto-generated method stub
		return null;
	}

	public Boolean objectInUse(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Map<String, Object>> findForMap(List<Object> values) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<?> find(List<Object> values) {
		// TODO Auto-generated method stub
		return null;
	}

	public Page findByPage(List<Object> conValues) {
		// TODO Auto-generated method stub
		return null;
	}

	public int getRowsCount(List<Object> values) {
		// TODO Auto-generated method stub
		return 0;
	}

}

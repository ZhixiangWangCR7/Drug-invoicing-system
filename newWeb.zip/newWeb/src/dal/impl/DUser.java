package dal.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import model.Page;
import model.User;
import dal.DB;
import dal.IUser;;


public class DUser implements IUser {

	@Override
	public int save(Object obj) {
		if (obj==null || obj instanceof model.User==false) 
			return 0;//参数不合法
		User user=(User)obj;
		String cmd="insert into user(id,name,number,passWord,createDate,role,roleId) values (?,?,?,?,?)";
		List<Object> values=new ArrayList<Object>();
		values.add(user.getId());
		values.add(user.getName());
		values.add(user.getNumber());
		values.add(user.getPassWord());
		values.add(user.getCreateDate());
		values.add(user.getRole());
		values.add(user.getRoleId());
		
		DB sql=DB.GetInstance();
		return sql.command(cmd,values);
		 
	}

	@Override
	public int batchSave(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int batchUpdate(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Object obj) {
		User user=(User)obj;
		String cmd="update user set name=?,number=?,passWord=?,role=?,roleId=? where id=?";
		List<Object> values=new ArrayList<Object>();
		values.add(user.getName());
		values.add(user.getNumber());
		values.add(user.getPassWord());
		values.add(user.getRole());
		values.add(user.getRoleId());
		values.add(user.getId());
		DB sql=DB.GetInstance();
		return sql.command(cmd,values);
	}

	@Override
	public int delete(Object obj) {
		if (obj==null || obj instanceof model.User==false) 
			return 0;//参数不合法
		User user=(User)obj;
		String cmd="delete from user where id=?";
		List<Object> values=new ArrayList<Object>();
		values.add(user.getId());
		DB sql=DB.GetInstance();   	
		return sql.command(cmd, values);
	}

	@Override
	public int batchDelete(List objs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getMe(Object obj) {
		// TODO Auto-generated method stub
		if (obj==null || obj instanceof model.User==false) 
			return 0;//参数不合法
		User user=(User)obj;
		String cmd="select * from user where id=?";
		List<Object> values=new ArrayList<Object>();
		values.add(user.getId());
		DB sql=DB.GetInstance();
		Map<String, Object> o1=sql.findByParam(cmd,values).get(0);
		return o1;
	}

	@Override
	public Boolean objectInUse(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String,Object>> findForMap(List<Object> values) {
        DB sql=DB.GetInstance();    
		return sql.findByParam("select * from user where name like ? limit ?,?", values);
	}

	@Override
	public List<?> find(List<Object> values) {
		// TODO Auto-generated method stub
		 DB sql=DB.GetInstance(); 
		 return sql.findByParam("select * from user where name like %?% limit ?,?", values);
	}

    @Override
	public Page findByPage(List<Object> conValues) {
    	
    	// 参数
    	if (conValues==null || conValues.size()!=3) return  null;
		if (conValues.get(1) instanceof Integer==false) return null;
		if (conValues.get(2) instanceof Integer==false) return null;
		DB sql=DB.GetInstance();
		List<Object> values=new ArrayList<Object>();
		values.add("%"+conValues.get(0)+"%");//获取name条件值,特别提示，通配符必%须作为值传递，不可以放在？一起
		int page=(int)conValues.get(1);
		int rows=(int)conValues.get(2);
		return sql.findByPage("*","user","name like ?",values,page,rows);
	}

    @Override
	public int getRowsCount(List<Object> values) {
		// TODO Auto-generated method stub
		return 0;
	} 
   

}



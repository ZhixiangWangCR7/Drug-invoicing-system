package dal.impl;

import java.sql.DriverManager;
import java.util.ArrayList;
import model.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class DrugImpl {
	public ArrayList<Drug> query(int number){
		  String driver = "com.mysql.jdbc.Driver";    
		  String url = "jdbc:mysql://localhost:3306/yggl?characterunicode=utf-8&useSSL=true";    
		  String use = "root";     
		  String password ="aptx4869";  
		  PreparedStatement sql=null;
		  Connection  conn=null;
		  ResultSet  rs=null;
		   ArrayList<Drug>  drugs= new  ArrayList<Drug>();
			
			    //1加载驱动 
			    try {
					Class.forName(driver);
				} catch (ClassNotFoundException e) {
				
					e.printStackTrace();
				}  
			     
			    try{
		    conn= DriverManager.getConnection(url,use,password); 
		    String str="select *from drug where id= ?";
		    sql =conn.prepareStatement(str);  
		    sql.setInt(1,number);
			rs= sql.executeQuery();
			while (rs.next()) {
				Drug drug=new Drug();
				drug.setId(rs.getString(1));
				drug.setName(rs.getString(2));
				drug.setMedType(rs.getString(3));
				drug.setUnit(rs.getString(4));
				drug.setNorm(rs.getString(5));
				drug.setArea(rs.getString(6));
			    
			    drugs.add(drug);   
			}
			rs.close();
			sql.close();
			conn.close();
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		    
			    return  drugs;

	}
}

package model;

import java.io.Serializable;
import java.util.Date; 

/***********************************
 * className:持久层超级父类
 * description:所有持久层的父类，必须被继承才能
 *             实例化
 * createDate:2017-11-8 10:32
 * author:王平华
 * version:1.0.0.0
 ************************************/
public abstract class AbsSuperModel implements Serializable {
	private String id="";//对象的ID，唯一性
	private String name="";//对象名称
	private Date createDate=new Date();//对象创建时间
	private String status="";//对象状态
	private String description="";//备注说明
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}


}

package model;

public class Drug extends AbsSuperModel {
	private String medType="";
    private String unit="";
    private String norm="";
    private String area="";
    private float buyPrice;
    private float bid;
    private float profit;
    public void setMedType(String medType) {
		this.medType = medType;
	}
    public void setUnit(String unit) {
		this.unit = unit;
	}
    public void setNorm(String norm) {
		this.norm = norm;
	}
    public void setArea(String area) {
		this.area = area;
	}
    public void setBuyPrice(float buyPrice) {
		this.buyPrice = buyPrice;
	}
    public void setBid(float bid) {
		this.bid = bid;
	}
    public void setProfit(float profit) {
		this.profit = profit;
	}
    public String getMedType() {
		return medType;
	}
    public String getUnit() {
		return unit;
	}
    public String getNorm() {
		return norm;
	}
    public String getArea() {
		return area;
	}
    public float getBuyPrice() {
		return buyPrice;
	}
    public float getBid() {
		return bid;
	}
    public float getProfit() {
		return profit;
	}
}

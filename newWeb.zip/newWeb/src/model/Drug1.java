package model;

public class Drug1 extends AbsSuperModel {
	private String rePurchases="";
	private float buyPrice;
	public void setRePurchases(String rePurchases) {
		this.rePurchases = rePurchases;
	}
	public void setBuyPrice(float buyPrice) {
		this.buyPrice = buyPrice;
	}
	public String getRePurchases() {
		return rePurchases;
	}
	public float getBuyPrice() {
		return buyPrice;
	}

}

package model;

public class Drug2 extends AbsSuperModel {
      private String saVolume="";
      private float bid;
      public void setSaVolume(String saVolume) {
		this.saVolume = saVolume;
	}
      public void setBid(float bid) {
		this.bid = bid;
	}
      public String getSaVolume() {
		return saVolume;
	}
      public float getBid() {
		return bid;
	}
}

package model;

public class Drug3 extends AbsSuperModel {
	private String rePurchases="";
	private String saVolume="";
	private String inventory="";
	public void setRePurchases(String rePurchases) {
		this.rePurchases = rePurchases;
	}
	public void setSaVolume(String saVolume) {
		this.saVolume = saVolume;
	}
	public void setInventory(String inventory) {
		this.inventory = inventory;
	}
	public String getRePurchases() {
		return rePurchases;
	}
	public String getSaVolume() {
		return saVolume;
	}
	public String getInventory() {
		return inventory;
	}

}

package model; 
import java.util.List;
import java.util.Map;  
/**
 * 类名称：数据分页实体类
 * @author Administrator
 *
 */
public class Page {
	private Integer page;//表示页码
	private Integer pageRows;//每页行数
	private Integer total;//查询符合要求的总行数
	private List<Map<String,Object>> rows=null;//返回查询的数据
	 
	public Integer getPage() {
		return page;
	}
	public void setPage(Integer page) {
		this.page = page;
	}
	public Integer getPageRows() {
		return pageRows;
	}
	public void setPageRows(Integer pageRows) {
		this.pageRows = pageRows;
	}
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}
	public List<Map<String, Object>> getRows() {

		return rows;
	}
	public void setRows(List<Map<String, Object>> rows) {
		this.rows = rows;
	}
	 
}

package model;

public class Role extends AbsSuperModel {
      private String power="";
      public void setPower(String power) {
		this.power = power;
	}
      public String getPower() {
		return power;
	}
}

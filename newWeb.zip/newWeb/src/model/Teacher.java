package model;

public class Teacher extends AbsSuperModel{
	private String number;//工号

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}
	

}

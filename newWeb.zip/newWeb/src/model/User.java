package model;

public class User extends AbsSuperModel {
	private String number="";
    private String passWord="";
    private String role="";
    private int roleId;
   public String getNumber() {
	   return number;
   }
   public String getPassWord() {
       return passWord;
   }
   public String getRole() {
	return role;
   }
   public int getRoleId() {
	return roleId;
   }
   public void setNumber(String number) {
	  this.number = number;
   }
   public void setPassWord(String passWord) {
       this.passWord = passWord;
   }
   public void setRole(String role) {
	this.role = role;
   }
   public void setRoleId(int roleId) {
	this.roleId = roleId;
   }
}

